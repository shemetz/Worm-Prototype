# Worm-Prototype

What is this game?

https://docs.google.com/document/d/1L3nGMw_dKx-_KTVtWRC8zSRwRdbyTDyV7Fox-EcoqnA/edit

(based on:  https://docs.google.com/document/d/1UzIRCb-MXHwgBCgyyd5Y-6JjaWORyJQPAqvcVjP8Njk/edit )


Where are all the nifty documents?

The game's Design Doc https://docs.google.com/document/d/1L3nGMw_dKx-_KTVtWRC8zSRwRdbyTDyV7Fox-EcoqnA/edit

Elements Combinations https://docs.google.com/spreadsheets/d/14DyF6FfWyt09ikgQsjxNCQ1jBtaFs7EsXumbo822C5s/edit#gid=0

All of the Abilities! https://docs.google.com/document/d/1Qn4M3nqWyG0keltD90LMy_V2AkFthZT30SNqNkg6QVg/edit

Meta page for above ^ https://docs.google.com/document/d/17sfCmiBrGv4_-jcKTJxBXwDG7PloY5Te_v8vAL4sM-U/edit

Elemental Differences https://docs.google.com/spreadsheets/d/1IoppOkDlEO9TtYz3EgBC4GPI4slSCs6-D1OEoZSdEQk/edit#gid=0

Feature Documentation https://docs.google.com/document/d/1N57KeVifPI16wT2ZaxozkrYXuy7mKx2EDr1Z9Xkf3Bs/edit 

Perks - and also Tags https://docs.google.com/document/d/1Uba2t7zx1bDKseqgOWvFmPQNVqTwqwfLshUx8wbIMDM/edit
