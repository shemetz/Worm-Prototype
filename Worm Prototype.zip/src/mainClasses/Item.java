package mainClasses;

/**
 * Items that can exist in inventories. TODO
 */
public class Item
{
	int weight;
}
